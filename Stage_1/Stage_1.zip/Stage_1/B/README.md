
Marked Entity Type: <b>Person Names</b>

Tags Used: <b>&lt;b&gt;</b> to denote start and <b>&lt;/b&gt;</b> to denote end

For example:

&lt;b&gt;Chakshu Ahuja&lt;/b&gt;, &lt;b&gt;Geetika Jain&lt;/b&gt; and &lt;b&gt;Swati Anand&lt;/b&gt; are working together on Data Science project.

The messages will be "unwrapped" by sculptor &lt;b&gt;Richard Wentworth&lt;/b&gt;, who is responsible for decorating the tree with broken plates and light bulbs. (Ref. 001.txt)

The revival, directed by &lt;b&gt;David Leveaux&lt;/b&gt;, will also star &lt;b&gt;Jessica Lange&lt;/b&gt; as the domineering mother, &lt;b&gt;Amanda Wingfield&lt;/b&gt;. (Ref 019.txt)