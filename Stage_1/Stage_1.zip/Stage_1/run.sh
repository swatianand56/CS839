python3 main.py
python3 main.py run "NN"